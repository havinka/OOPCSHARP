﻿using System;
namespace P10_Zoo
{
	public class Gorilla
	{
		public Gorilla()
		{
		}
	}
}

