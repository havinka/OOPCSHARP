﻿using System;
namespace P10_Zoo
{
	public class Lizard
	{
		public Lizard()
		{
		}
	}
}

