﻿namespace P10_Zoo;
class StartUp
{
    public static void Main(string[] args)
    {

    }
}

