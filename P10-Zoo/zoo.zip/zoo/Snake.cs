﻿using System;
namespace P10_Zoo
{
	public class Snake
	{
		public Snake()
		{
		}
	}
}

