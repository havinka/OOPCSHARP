﻿using System;
namespace P10_Zoo
{
	public class Bear
	{
		public Bear()
		{
		}
	}
}

