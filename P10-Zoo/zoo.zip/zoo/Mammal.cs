﻿using System;
namespace P10_Zoo
{
	public class Mammal
	{
		public Mammal()
		{
		}
	}
}

