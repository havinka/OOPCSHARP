﻿using System;
namespace P10_Zoo
{
	public class Animal
	{
		public string Name { get; set; }

        public Animal(string name)
        {
            Name = name;
        }
    }
}

